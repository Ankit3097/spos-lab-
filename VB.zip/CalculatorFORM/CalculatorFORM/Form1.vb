﻿Imports CalculatorDLL
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Add As New CalculatorDLL.Calculator
        Label3.Text = Add.add(CDbl(TextBox1.Text), CDbl(TextBox2.Text)).ToString
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim Subt As New CalculatorDLL.Calculator
        Label3.Text = Subt.subtract(CDbl(TextBox1.Text), CDbl(TextBox2.Text)).ToString
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim Mul As New CalculatorDLL.Calculator
        Label3.Text = Mul.mul(CDbl(TextBox1.Text), CDbl(TextBox2.Text)).ToString
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim Div As New CalculatorDLL.Calculator
        Label3.Text = Div.div(CDbl(TextBox1.Text), CDbl(TextBox2.Text)).ToString
    End Sub
End Class
