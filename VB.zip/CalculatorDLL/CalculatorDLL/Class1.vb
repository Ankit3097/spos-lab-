﻿Public Class Calculator
    Public Function add(ByVal Value1 As Double, ByVal Value2 As Double)
        Dim Result As Double
        Result = Value1 + Value2
        Return Result
    End Function

    Public Function subtract(ByVal Value1 As Double, ByVal Value2 As Double)
        Dim Result As Double
        Result = Value1 - Value2
        Return Result
    End Function

    Public Function mul(ByVal Value1 As Double, ByVal Value2 As Double)
        Dim Result As Double
        Result = Value1 * Value2
        Return Result
    End Function

    Public Function div(ByVal Value1 As Double, ByVal Value2 As Double)
        Dim Result As Double
        Result = Value1 / Value2
        Return Result
    End Function

End Class
